package utility;

import java.util.ArrayList;

import org.openqa.selenium.By;

public class Constant {
	 	public static String currentDir = System.getProperty("user.dir");
	    public static final String DEV_URL = "https://rc.steadfasthub.com/svu/brokers/QBEBROKER/Modules/GIBroker/Public/Home.aspx";
	    public static final String SYS_URL = "http://ptm.tpos.qbe.com/qbe/QBETravel?";
	    public static final String UAT_URL = "https://rc.steadfasthub.com/svu/brokers/QBEBROKER/Modules/GIBroker/Public/Home.aspx";
	    public static final String Username = "";
	    public static final String Password =""; 
		public static final String Path_Excel = currentDir+"//src//main//java//testData//";
		public static final String File_TestData = "TestData.xlsx";
		public static final String File_RunManager = "Run_Manager.xlsx";	
		public static final String Path_ScreenShot =  currentDir+ "//src//Screenshots";
		public static final String Path_IEDriver = currentDir+"//src//main//java//Jar//IEDriverServer.exe";
		public static final String Path_FireFoxDriver = currentDir+"//src//Jar//geckodriver.exe";
		public static final String Path_ChromeDriver = currentDir+"//src//main//java//Jar//Jar1//chromedriver.exe";
		public static  String TC_Name;
		public static  String PolicyNumber;
		public static String val;
		public static String page_name;
		public static String ENV_URL;
		public static String sBrowserName;
		public static String environe;
		public static String[] stockArr;
		public static String Parentwindow;
		public static ArrayList<String> dataToWrite = new ArrayList<String>();
		public static ArrayList<String> tc;
		public static String Newtestcase;
		public static By LocatorV;
	}
