package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Repository.RepositoryParser;

public class Reusable {
	
	static String DestFile;
	
	public static void Enter_Value_WebElement(WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name) throws Exception
	{
	
		
		try
		{
			 Reusable.GetThefilename( Excel_Workbook);
			 String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
		     int val_Uname=ExcelUtils.get_column(object_value,DestFile,ExcelPath);   
		     String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname); 
			
			if (sUserName!="")
	    	{
			
			WebElement Edit_Username=RepositoryParser.Create_Objects(object_value,DestFile); 	
	    	Edit_Username.clear();  
	    		    	
	    	
	    	 	Reusable.takeScreenshot(driver, object_value,TC_Name);
	    	 	
	    		String Label = Edit_Username.getAttribute("name");
	    		Edit_Username.clear(); 
	    		Edit_Username.sendKeys(sUserName);
	    		Thread.sleep(1000);
	    		//Edit_Username.sendKeys(String.valueOf(sUserName));
	            Log.info(sUserName+" is entered in text box" );
	            Extend_Report.AddReport( sUserName +" is Entered in the "+ Label +" field", "Pass");
	            
	    	}
		}
    	
    	catch(Exception e)
		{	
    		
    		ExcelUtils.setExcelFile(Constant.Path_Excel+Constant.File_RunManager, "Run_Manager");		 
    		int val_run=ExcelUtils.getRowContains_manager(TC_Name, 0, "Run_Manager");		 
    		ExcelUtils.setCellData_Manager("FAIL", val_run, 2);
    		 Extend_Report.AddReport("Error is  Enter_Value_WebElement", "Fail");
    		 
    		System.out.println("Error in Enter_Value_WebElement " + e.toString());
    		Log.info(" Error in entered in text box" );
		}
		
	}
	
	public static void Click_Button(WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name) throws Exception
	{
		try{
			Reusable.GetThefilename( Excel_Workbook);
			String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
	    	int val_Uname=ExcelUtils.get_column(object_value,DestFile,ExcelPath);            	
	    	String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname);
	    	if(sUserName!="")
	    	{
			WebElement Edit_Username=RepositoryParser.Create_Objects(object_value,DestFile);
			  
	    	String name="";
	    	String classvalue ="";
	    		
	    	
		    		Reusable.takeScreenshot(driver, object_value,TC_Name);
		    		String Label = Edit_Username.getAttribute("title");
	    		if (Label!= null)
	    		{
	    			 name = Edit_Username.getAttribute("name");
	    			 classvalue = Edit_Username.getAttribute("class");
	    			 if(classvalue.contains("disabled"))
	    			 {
	    				 while (classvalue.contains("disabled")== true)
	    					{
	    						
	    					 Thread.sleep(1000);
	    					 classvalue = Edit_Username.getAttribute("class");
	    					}
	    			 }
	    			 else {
	    			 WebDriverWait wait = new WebDriverWait(driver, 20);
	    			 Edit_Username = wait.until(ExpectedConditions.elementToBeClickable(Edit_Username));
	    			 
	    			 }
	    			
	    			 
	    		}
	    		else
	    		{
	    			Label = Edit_Username.getAttribute("title");
	    			 classvalue = Edit_Username.getAttribute("class");
	    			
	    		}
	    		
	    			
	    		
	    		
	    		Edit_Username.click();
	    		driver.manage().timeouts().implicitlyWait(2000,TimeUnit.SECONDS);							
				
	            Log.info(sUserName+" is Clicked " );
	            
	        	if (Label!= null)
	    		{
	            	
					Extend_Report.AddReport(Label +" Is Clicked", "Pass");
	    		}
	        	else
	        	{
	        		Extend_Report.AddReport( object_value +" Is Clicked", "Pass");
	        	}
	        	Log.info(object_value+" is Clicked in " );
	    	}
			}
		catch(Exception e)
		{
			
			ExcelUtils.setExcelFile(Constant.Path_Excel+Constant.File_RunManager, "Run_Manager");		 
    		int val_run=ExcelUtils.getRowContains_manager(TC_Name, 0, "Run_Manager");		 
    		ExcelUtils.setCellData_Manager("FAIL", val_run, 2);
			Extend_Report.AddReport("Error is  Click_Button", "Fail");
			Log.info(object_value+" is not Clicked " );
			System.out.println("Error in Click_Button " + e.toString());
		}
    	
    	
		
	}
	
	public static void Select_Value_DropDown(WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name) throws Exception
	{
	
		
		try
		{
			Reusable.GetThefilename( Excel_Workbook);
			String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
	    	int val_Uname=ExcelUtils.get_column(object_value,DestFile,ExcelPath);   
	    	String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname);
	    	if (sUserName!="")
	    	{
			   WebElement Edit_Username=RepositoryParser.Create_Objects(object_value,DestFile); 
				Reusable.takeScreenshot(driver, object_value,TC_Name);
	    		Select select = new Select(Edit_Username);
	    		select.selectByVisibleText(sUserName);
	    		Thread.sleep(1000);
	            Log.info(sUserName+" is entered in text box" );
	            Extend_Report.AddReport( sUserName +" is Selected in the "+ object_value +" DropDown", "Pass");
	    	}
	    	Log.info(sUserName+" is  Selected " );
		}
    	
    	catch(Exception e)
		{
    		
    		ExcelUtils.setExcelFile(Constant.Path_Excel+Constant.File_RunManager, "Run_Manager");		 
    		int val_run=ExcelUtils.getRowContains_manager(TC_Name, 0, "Run_Manager");		 
    		ExcelUtils.setCellData_Manager("FAIL", val_run, 2);
    		Extend_Report.AddReport("Error is  Select_Value_DropDown", "Fail");
    		Log.info(" Error is  Select_Value_DropDown " );
    		System.out.println("Error in Select_Value_DropDown " + e.toString());
		}
		
	}
	public static void Check_WebElement(WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name) throws Exception
	{
	
		
		try
		{
			Reusable.GetThefilename( Excel_Workbook);			
			String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
	    	int val_Uname=ExcelUtils.get_column(object_value,DestFile,ExcelPath);            	
	    	String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname); 
	    	if (sUserName!="")
	    	{
	    	WebElement Edit_Username=RepositoryParser.Create_Objects(object_value,DestFile); 
	    	
	    		Reusable.takeScreenshot(driver, object_value,TC_Name);
	    		Constant.val=Edit_Username.getText();
	    			    

	    		//Edit_Username.click();
	    		
	    		if (Constant.val.contains(sUserName))
	    		{
	    			Log.info(sUserName+" is Present in Page" );
		            Extend_Report.AddReport( Constant.val +" is Present in the "+ object_value +" Element ", "Pass");
		            Log.info(Constant.val +" is Present in the "+ object_value +" Element " );
	    		}
	    		else
	    		{
	    			ExcelUtils.setExcelFile(Constant.Path_Excel+Constant.File_RunManager, "Run_Manager");		 
	        		int val_run=ExcelUtils.getRowContains_manager(TC_Name, 0, "Run_Manager");		 
	        		ExcelUtils.setCellData_Manager("FAIL", val_run, 2);
	        		Extend_Report.AddReport( Constant.val +" is NOT Present in the "+ object_value +" Element ", "Fail");
	        		
	    		}
	            
	    	}
		}
    	
    	catch(Exception e)
		{
    		
    		ExcelUtils.setExcelFile(Constant.Path_Excel+Constant.File_RunManager, "Run_Manager");		 
    		int val_run=ExcelUtils.getRowContains_manager(TC_Name, 0, "Run_Manager");		 
    		ExcelUtils.setCellData_Manager("FAIL", val_run, 2);
    		Extend_Report.AddReport("Error is  Check_WebElement :" +e.toString(), "Fail");
    		
		}
		
	}
	
	public static void Click_CheckBox(WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name) throws Exception
	{
	
		
		try
		{
			Reusable.GetThefilename( Excel_Workbook);
			String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
	    	int val_Uname=ExcelUtils.get_column(object_value,DestFile,ExcelPath);            	
	    	String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname);
	    	
	    	if (sUserName!="")
	    	{
	    		WebElement Edit_Username=RepositoryParser.Create_Objects(object_value,DestFile);  
	    		Reusable.takeScreenshot(driver, object_value,TC_Name);
	    		
	    		if ( !Edit_Username.isSelected() )
	    		{      
	    				Edit_Username.click();
	    			
	    				Log.info(Edit_Username +" is Clicked in the Check_Box " );
	    		}
	    		
	    		
	    		Extend_Report.AddReport("CheckBox "+ object_value +"is Selected", "Pass");	
	            
	    	}
		}
    	
    	catch(Exception e)
		{
    		
    		ExcelUtils.setExcelFile(Constant.Path_Excel+Constant.File_RunManager, "Run_Manager");		 
    		int val_run=ExcelUtils.getRowContains_manager(TC_Name, 0, "Run_Manager");		 
    		ExcelUtils.setCellData_Manager("FAIL", val_run, 2);
    		Extend_Report.AddReport("Error is  Click_CheckBox :"+e.toString(), "Fail");
    		
		}
		
	}
	public static void Click_RadioButton(WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name) throws Exception
	{
	
		
		try
		{
			Reusable.GetThefilename( Excel_Workbook);
			String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
	    	int val_Uname=ExcelUtils.get_column(object_value,DestFile,ExcelPath);            	
	    	String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname); 	    	
	    	if (sUserName!="")
	    	{ 
	    		WebElement Edit_Username=RepositoryParser.Create_Objects(object_value,DestFile); 
	    		Reusable.takeScreenshot(driver, object_value,TC_Name);
	    		
	    		if ( !Edit_Username.isSelected() )
	    		{
	    				Edit_Username.click();
	    				Log.info(Edit_Username +" is Clicked in the RadioButton " );
	    		}
	    		
	    		Extend_Report.AddReport("RadioButton "+ object_value +"is Selected", "Pass");
	    	}
		}
    	
    	catch(Exception e)
		{
    		
    		ExcelUtils.setExcelFile(Constant.Path_Excel+Constant.File_RunManager, "Run_Manager");
    		
    		int val_run=ExcelUtils.getRowContains_manager(TC_Name, 0, "Run_Manager");		 
    		ExcelUtils.setCellData_Manager("FAIL", val_run, 2);
    		Extend_Report.AddReport("Error is  Click_RadioButton :"+e.toString(), "Fail");
    		
		}
		
	}
	public static void takeScreenshot(WebDriver driver,String sTestCaseName,String TC_Name) throws Exception{
		try{
						
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// Now you can do whatever you need to do with it, for example copy somewhere
			String Path=System.getProperty("user.dir") +"//src//Screenshots//";		
			
			String TC = Constant.TC_Name+TC_Name+sTestCaseName+".png";
			//String TC = Path+TC_Name+sTestCaseName+".png";
			
			FileUtils.copyFile(scrFile, new File(TC));
			
		} catch (Exception e){
			System.out.println("Screen Shot"+e.toString());
			Extend_Report.AddReport("Error is  takeScreenshot", "Fail");
			Log.error("Class Utils | Method takeScreenshot | Exception occured while capturing ScreenShot : "+e.getMessage());
			//throw new Exception();
		}
	}
	
	//Added to synchronize on 17th August 2017 
	public static void waitfortheobject(String sID) {	
			
			WebDriver driver = null;
			WebDriverWait w = new WebDriverWait(driver,20);
			w.ignoring(NoSuchElementException.class);
			WebElement P = null;								
			P= w.until(ExpectedConditions.visibilityOfElementLocated(By.id(sID)));
			
		
		}
	
	// Written by Richa to take care of value entered by keystroke.
	
	public static void Enter_value_keystrokes(WebDriver driver,String object_value,String Excel_Workbook,int iTestCaseRow) throws Exception
	{
		
		XSSFSheet ExcelWSheet;
	    XSSFWorkbook ExcelWBook;
	    XSSFWorkbook Excel_File;
	    XSSFCell Cell;
	    XSSFRow Row;
	
	try{		
		   Reusable.GetThefilename( Excel_Workbook); 
	    	//WebElement Edit_Username=RepositoryParser.Create_Objects(object_value,Excel_Workbook); 	
	 		String currentDir = System.getProperty("user.dir");        
	 		FileInputStream ExcelFile = new FileInputStream(currentDir+"\\src\\main\\java\\Repository\\"+Excel_Workbook+".xlsx");     
	         ExcelWBook = new XSSFWorkbook(ExcelFile);
	         ExcelWSheet = ExcelWBook.getSheet("Sheet1");
	         int RowCount = ExcelWSheet.getLastRowNum();
	          		
				
				for (int i=1;i<RowCount+1;i++)
	 		{
				
					Cell = ExcelWSheet.getRow(i).getCell(0);					
						String CellData = Cell.getStringCellValue();	                    
	                 Cell = ExcelWSheet.getRow(i).getCell(1);
                  String CellData1 = Cell.getStringCellValue();     			
	                
	                
				//	if(object_value.equalsIgnoreCase(CellData))
	              //   {
	                // 	String locatorType = CellData1.split(":")[0];
	             		//String locatorValue = CellData1.split(":")[1];	
                  String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
	             		int val_Uname=ExcelUtils.get_column(object_value,Excel_Workbook,ExcelPath);            	
	        	    	String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname); 
	        	    	
	        	    	if (sUserName!="")
	        	    	{
          	    		 Actions builder2 = new Actions(driver);
          	    		  //builder2.sendKeys(Keys.CONTROL+"a").perform();
          	    		//builder2.keyDown(Keys.SHIFT).sendKeys(Keys.HOME).keyUp(Keys.SHIFT).build().perform();;
          	    		//builder2.moveToElement(Edit_Username).click().sendKeys(Keys.chord(Keys.CONTROL,"a")).build().perform();
          	    		 builder2.sendKeys(Keys.chord(Keys.CONTROL,"a")).sendKeys(Keys.DELETE).build().perform();
          	    		 builder2.sendKeys(Keys.DELETE).build().perform();
          	    		//builder2.sendKeys(sUserName).build().perform();
          	    		        	    		 
          	    		 
          	    		 int  LengthOfStr = sUserName.length();
	        	    		
	        	    		for (int j = 0;j < LengthOfStr; j++ ){
	        	    			char c = sUserName.charAt(j);
	        	    			String s = new StringBuilder().append(c).toString();
	        	    			builder2.sendKeys(s).build().perform();
	        	    			
	        	    			}
	        	    		
          	    		 	 
							 Thread.sleep(1000);
          	    		 	
							
	        	    	}
	        	    	break; 	
	                 
	//}
					
					
	
	
	 		}
	}
				  catch(Exception e)
					{
	             	
	             	System.out.println("Exception in Object Creation " + e.toString());
					}
					
	
	}
	
	//Written by Richa to fetch the data from application (application number) and write it to excel.
	
	public static void WebTableApplication_WriteinExcel(WebDriver driver, String TC_Number) throws Exception
	{
		/*try{
			
			// Need to make it excel friendly enter the data in excel.
			
			
		 WebElement table  = driver.findElement(By.xpath("//*[contains(@class,'ang box x-component')]"));
		//	WebElement table  = driver.findElement(By.xpath("//*[@class='rv-summary-table x-component'])"));
			
			
		
	//Get all the tr elements from the table
			List<WebElement> allrows = table.findElements(By.tagName("tr"));
			
	// iterate over them getting the cells
			for (WebElement row :allrows ){
				List<WebElement> cells = row.findElements(By.tagName("td"));
				
				//Print the contents of each cell
				for (WebElement cell: cells){
					String cellValue = (cell.getText());
					Constant.PolicyNumber = (cell.getText());
					Date date = new Date();
					String date1 = date.toString();
					date1 = date1.replaceAll("\\s", "");
					String cellValue1 = Constant.PolicyNumber  + " " + TC_Number + " " + date1 + " " + Constant.val;
					
					if (cellValue.contains("Policy")){
						String[] cellValue2 = cellValue1.split("\\s+");
						Reusable.writeExcel("C:\\Users\\889128\\Desktop\\Selenium Luna\\selenium", "Datawrite.xlsx", "Sheet1", cellValue2);
												
					}
					break;
				}
				break;
			
				
				
			}
	                 
	}
							 		
				  catch(Exception e)
					{
	             	
	             	System.out.println("Exception in Object Creation " + e.toString());
					}*/
		
		
try{
			
			// Need to make it excel friendly enter the data in excel.
	/*ArrayList<String> dataToWrite = new ArrayList<String>();	
			
		WebElement table  = driver.findElement(By.xpath("//*[@class='rv-summary-table x-component'])"));
			
			
		
	//Get all the tr elements from the table
			List<WebElement> allrows = table.findElements(By.tagName("tr"));
			for (WebElement row :allrows ){
				List<WebElement> cells = row.findElements(By.tagName("td"));
				for (WebElement cell: cells){
					String cellValue = cell.getText();
					dataToWrite.add(cellValue);
										
				}
				Date date = new Date();
				String date1 = date.toString();
				date1 = date1.replaceAll("\\s", "");
				dataToWrite.add(date1);
				String[] stockArr = new String[dataToWrite.size()];
				stockArr = dataToWrite.toArray(stockArr);*/
				//Reusable.writeExcel("C:\\Users\\889128\\Desktop\\Selenium Luna\\selenium", "Datawrite.xlsx", "Sheet1", Constant.stockArr);
				
				}
			




catch(Exception e)
{
	
	System.out.println("Exception in Object Creation " + e.toString());
}
		
	
	}
	


	public static void  writeExcel(String filepath, String fileName, String sheetName,String[] datatowrite) throws IOException{
		//Create an object of file class to open a xlsx file
				
		/*FileInputStream file = new FileInputStream(new File("C:\\Users\\889128\\Desktop\\Selenium Luna\\selenium\\Datawrite.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0);*/

		
		
		// Create first row
		
		File file = new File(filepath+"\\"+fileName);
		
		//Create and object of file inputstream class to read excel file
		
		FileInputStream inputstream = new FileInputStream(file);
		Workbook Guruworkbook = null;
		//Find the file extension by splitting the file name and get only the extension
		
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		//Check the condition if the file is xlsx
		if(fileExtensionName.equals(".xlsx")){
			// Create object for XSSworkbook
			Guruworkbook = new XSSFWorkbook(inputstream);
			
		}
		// Check condition if the file xls
		else if (fileExtensionName.equals(".xls")){
			Guruworkbook = new HSSFWorkbook(inputstream);
		}
		
		//Read excel sheet by sheet name
		Sheet sheet =  Guruworkbook.getSheet(sheetName);
		
		//Get the current count of rows in the excel sheet
		
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		
		// get the first row from the excel sheet
		Row row = sheet.getRow(0);
		
		// create a new row and append it at last of the sheet.
		Row newRow = sheet.createRow(rowCount+1);
		
		// Create a loop over the cell of newly created row
		for (int j =0 ; j< row.getLastCellNum(); j++){
			
			//Fill data in the row
			Cell cell = newRow.createCell(j);
			cell.setCellValue(datatowrite[j]);
		}
		
		// close input string
		
		inputstream.close();
		
		// Create an object for fileoutputstring to write the date
		
		FileOutputStream outputstream = new FileOutputStream(file);
		
		//Write data in excel sheet
		Guruworkbook.write(outputstream);
		
		//Close the output string.
		outputstream.close();
		
		
	}
	
	public static void VerifyWebTable (WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name)throws Exception
	
	{
		// Comments this is the temporarily solution need to change it to make it excel friendly.
try{
	        Reusable.GetThefilename( Excel_Workbook);
			WebElement Edit_Username=RepositoryParser.Create_Objects(object_value,DestFile);
			
			 List<WebElement> allrows = Edit_Username.findElements(By.tagName("tr"));
			 int rowscount = allrows.size();
			 List<WebElement> allcols = Edit_Username.findElements(By.tagName("td"));
			 int colcount = allcols.size();
			 String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
			 int val_Uname=ExcelUtils.get_column(object_value,Excel_Workbook,ExcelPath);   
		    	String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname);
		    	
		    	
		    	if (sUserName.contains("Double")){
		    		String sUserName1 =  Constant.PolicyNumber;
			    	sUserName = sUserName1.replaceAll("\\s+", "");
		    		//sUserName = sUserName.replace("_Double", "");
		    		outerloop :
		    		for(WebElement row: allrows){
				        List<WebElement> Cells = row.findElements(By.tagName("td"));
				        for (WebElement cell: Cells){
				        	String cellValue = (cell.getText());
				      			        				    	
				        	if (cellValue.contains(sUserName)) {
				        	  		Actions builder = new Actions(driver);
					           	builder.moveToElement(cell).doubleClick().build().perform();
					            Thread.sleep(1000);	
					           	break outerloop;					
							}
				        	
				 
		    		
		    	}
				        
		    		}
		    	}
		    	else if  (sUserName.equalsIgnoreCase("Variable" )|| sUserName.equalsIgnoreCase("Creation T" )){
		    	 if(sUserName.equalsIgnoreCase("Variable" )){
		    		String sUserName1 = Constant.PolicyNumber;
		    	sUserName = sUserName1.replaceAll("\\s+", "");
		    	}
		    	
		    	outerloop :
			for(WebElement row1: allrows){
			        List<WebElement> Cells1 = row1.findElements(By.tagName("td"));
			        for (WebElement cell: Cells1){
			        	String cellValue = (cell.getText());
			        Thread.sleep(1000);			    	
			        	if (cellValue.contains(sUserName)){
			        		cell.click();
			        		 Thread.sleep(3000);	

							
			        	break outerloop;						
						}
			        
			 }
		    		}
		    	}
}
		    	
		    	
			

    		    			
			
		
catch(Exception e)
{
	
	System.out.println("Exception in Object Creation " + e.toString());
}

		


	}
	
	
	public static void VerifyWebTableScreen (WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name)throws Exception
	
	{
		// Comments this is the temporarily solution need to change it to make it excel friendly.
try{
	Reusable.GetThefilename( Excel_Workbook);
	WebElement Edit_Username=RepositoryParser.Create_Objects(object_value,DestFile);
	List<WebElement> allrows = Edit_Username.findElements(By.tagName("tr"));
	
	outerloop:
	for (WebElement row :allrows ){
		List<WebElement> cells = row.findElements(By.tagName("td"));
		for (WebElement cell: cells){
			String cellValue = cell.getText();
			//Constant.dataToWrite.add(cellValue);
			if (cellValue.contains("Policy") && Constant.page_name.equalsIgnoreCase("NSR") ){
				Constant.PolicyNumber = cellValue;
				Constant.PolicyNumber = Constant.PolicyNumber.replace("Policy Number", "");
				Constant.PolicyNumber = Constant.PolicyNumber.trim().replaceAll("\n", "");
				//Constant.dataToWrite.clear();
				Constant.dataToWrite.add(Constant.PolicyNumber);
				break outerloop;
			}
			
							
			}
			
		}
	if(!Constant.dataToWrite.contains("Execution Date:")){
	Date date = new Date();
	SimpleDateFormat dt1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	String date1 = dt1.format(date);
	//date1 = date1.replaceAll("\\s", "");
	Constant.dataToWrite.add("Policy Number");
	//Constant.dataToWrite.add(Constant.val);
	Constant.dataToWrite.add(TC_Name);
	Constant.dataToWrite.add("Test case No.");	
	Constant.dataToWrite.add(date1);
	Constant.dataToWrite.add("Execution Date");
	
	
	
	}
	
	Constant.stockArr = new String[Constant.dataToWrite.size()];
	Constant.stockArr = Constant.dataToWrite.toArray(Constant.stockArr);
	
	
	
	
	
}
		    	
		    	
			

    		    			
			
		
catch(Exception e)
{
	
	System.out.println("Exception in Object Creation " + e.toString());
}

		


	}
	
	
	public static void PopUpaction(WebDriver driver,String object_value,String Excel_Workbook,int iTestCaseRow) throws Exception
	{
		
		XSSFSheet ExcelWSheet;
	    XSSFWorkbook ExcelWBook;
	    XSSFWorkbook Excel_File;
	    XSSFCell Cell;
	    XSSFRow Row;
	
	try{		
		
		    Reusable.GetThefilename( Excel_Workbook); 	
	 		String currentDir = System.getProperty("user.dir");        
	 		FileInputStream ExcelFile = new FileInputStream(currentDir+"\\src\\Repository\\"+Excel_Workbook+".xlsx");     
	         ExcelWBook = new XSSFWorkbook(ExcelFile);
	         ExcelWSheet = ExcelWBook.getSheet("Sheet1");
	         int RowCount = ExcelWSheet.getLastRowNum();
	          		
				
				for (int i=1;i<RowCount+1;i++)
	 		{
				
					Cell = ExcelWSheet.getRow(i).getCell(0);					
						String CellData = Cell.getStringCellValue();	                    
	                 Cell = ExcelWSheet.getRow(i).getCell(1);
                  String CellData1 = Cell.getStringCellValue();     			
	  
                  String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
	             		int val_Uname=ExcelUtils.get_column(object_value,Excel_Workbook,ExcelPath);            	
	        	    	String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname); 
	        	    	
	        	    	if (sUserName!="")
	        	    	{
	        	    		Constant.Parentwindow = driver.getWindowHandle();
							Set<String> windowhandles = driver.getWindowHandles();
							Iterator<String> iterator = windowhandles.iterator();
							while (iterator.hasNext()){
								String handle = iterator.next();
								driver.switchTo().window(handle);
								 String Parentwindowtitle = driver.getTitle();
								if(Parentwindowtitle.contains(sUserName)){
									driver.switchTo().window(handle);
									driver.manage().window().maximize();
																							
								}
							}
							
	                 	
	 		}
	        	    	break;
	}
				
	}
				  catch(Exception e)
					{
	             	
	             	System.out.println("Exception in Object Creation " + e.toString());
					}
					
	
	}
	
	public static void ParentPopUpaction(WebDriver driver,String object_value,String Excel_Workbook,int iTestCaseRow) throws Exception
	{
	
	
	try{		
		driver.switchTo().window(Constant.Parentwindow);
				
	}
				  catch(Exception e)
					{
	             	
	             	System.out.println("Exception in Object Creation " + e.toString());
					}
					
	
	}
	
	
	public static void iframeaction(WebDriver driver,String object_value,String Excel_Workbook,int iTestCaseRow) throws Exception
	{
		
	
	
	try{	
		XSSFSheet ExcelWSheet;
	    XSSFWorkbook ExcelWBook;
	   // XSSFWorkbook Excel_File;
	    XSSFCell Cell;
	    XSSFRow Row;
	    
		String currentDir = System.getProperty("user.dir");        
 		FileInputStream ExcelFile = new FileInputStream(currentDir+"\\src\\Repository\\"+Excel_Workbook+".xlsx");     
         ExcelWBook = new XSSFWorkbook(ExcelFile);
         ExcelWSheet = ExcelWBook.getSheet("Sheet1");
         int RowCount = ExcelWSheet.getLastRowNum();
             		
			
			for (int i=1;i<RowCount+1;i++)
 		{
				
				Cell = ExcelWSheet.getRow(i).getCell(0);					
					String CellData = Cell.getStringCellValue();	                    
                 Cell = ExcelWSheet.getRow(i).getCell(1);
                 String CellData1 = Cell.getStringCellValue();     			
                
                 if(object_value.equalsIgnoreCase(CellData))
                 {
                	 
                 	String locatorType = CellData1.split(":")[0];
             		String locatorValue = CellData1.split(":")[1];
             		
             		driver.switchTo().frame(driver.findElement(By.xpath(locatorValue)));
            		//firefox.switchTo().frame(firefox.findElement(By.xpath("//iframe[@class='gwt-Frame x-component']")));
             		break;	
             		
	}
                 	     
 				
				}
			
	}
				  catch(Exception e)
					{
	             	
	             	System.out.println("Exception in Object Creation " + e.toString());
					}
					
	
	}
	
	public static void Defaultframe(WebDriver driver,String object_value,String Excel_Workbook,int iTestCaseRow) throws Exception
	{
	
	
	try{		
		driver.switchTo().defaultContent();
				
	}
				  catch(Exception e)
					{
	             	
	             	System.out.println("Exception in Object Creation " + e.toString());
					}
	
	
	}
	public static void Tab_Function(WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name) throws Exception
	{
	
		
		try
		{ 
			Reusable.GetThefilename( Excel_Workbook);
			 String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
		     int val_Uname=ExcelUtils.get_column(object_value,DestFile,ExcelPath);   
		     String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname); 
			
			if (sUserName!="")
	    	{
				Actions builder2 = new Actions(driver);
				 Action seriesofaction2 = builder2.sendKeys(Keys.TAB).build();
				 seriesofaction2.perform();
				 Thread.sleep(1000);	
	    	}
		}
		
		catch(Exception e)
		{
     	
     	System.out.println("Exception in Object Creation " + e.toString());
		}

	}
	
	public static void ShiftTab_Function(WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name) throws Exception
	{
	
		
		try
		{
			Reusable.GetThefilename( Excel_Workbook);
			 String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
		     int val_Uname=ExcelUtils.get_column(object_value,DestFile,ExcelPath);   
		     String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname); 
			
			if (sUserName!="")
	    	{
				 Actions builder = new Actions(driver);
				 Action seriesofaction = builder.keyDown(Keys.SHIFT).sendKeys(Keys.TAB).keyUp(Keys.SHIFT).build();
				 seriesofaction.perform();
				 Thread.sleep(1000);	
	    	}
		}
		
		catch(Exception e)
		{
     	
     	System.out.println("Exception in Object Creation " + e.toString());
		}

	}
	
	public static void RightArrow_Function(WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name) throws Exception
	{
	
		
		try
		{
			Reusable.GetThefilename( Excel_Workbook);
			 String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
		     int val_Uname=ExcelUtils.get_column(object_value,DestFile,ExcelPath);   
		     String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname); 
			
			if (sUserName!="")
	    	{
				 Actions builder1 = new Actions(driver);
				 Action seriesofaction1 = builder1.sendKeys(Keys.RIGHT).build();
				 seriesofaction1.perform();
				 Thread.sleep(1000);	
	    	}
		}
		
		catch(Exception e)
		{
     	
     	System.out.println("Exception in Object Creation " + e.toString());
		}

	}
	
	public static void Enter_Function(WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name) throws Exception
	{
	
		
		try
		{
			Reusable.GetThefilename( Excel_Workbook);
			 String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
		     int val_Uname=ExcelUtils.get_column(object_value,DestFile,ExcelPath);   
		     String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname); 
			
			if (sUserName!="")
	    	{
				 Actions builder3 = new Actions(driver);
				 Action seriesofaction3 = builder3.sendKeys(Keys.ENTER).build();
				 seriesofaction3.perform();
				 Thread.sleep(1000);	
	    	}
		}
		
		catch(Exception e)
		{
     	
     	System.out.println("Exception in Object Creation " + e.toString());
		}

	}
	
	public static void Space_Function(WebDriver driver,int iTestCaseRow,String object_value, String Excel_Workbook,String TC_Name) throws Exception
	{
	
		
		try
		{
			Reusable.GetThefilename( Excel_Workbook);
			 String ExcelPath = Constant.Path_Excel + Constant.File_TestData;
		     int val_Uname=ExcelUtils.get_column(object_value,DestFile,ExcelPath);   
		     String sUserName = ExcelUtils.getCellData(iTestCaseRow, val_Uname); 
			
			if (sUserName!="")
	    	{
				Actions builder4 = new Actions(driver);
				 Action seriesofaction4 = builder4.sendKeys(Keys.SPACE).build();
				 seriesofaction4.perform();
				 Thread.sleep(1000);	
	    	}
		}
		
		catch(Exception e)
		{
     	
     	System.out.println("Exception in Object Creation " + e.toString());
		}

	}
	
	public static void GetThefilename(String Excel_Workbook) throws Exception
	{
	
		
		try
		{
			
		
			File dir = new File (Constant.currentDir+"\\src\\main\\java\\Repository");
   		 File [] filelist = dir.listFiles();
   	        for (File file: filelist) {
   	        	 DestFile = file.getName();
   	        	if (DestFile.contains(Excel_Workbook) ) {
   	        		String[] parts1 = DestFile.split(Pattern.quote("."));
   	        		DestFile = parts1[0];
   	        		break;
   	        		
   	        	}
		}
   	        
		}
		
	
		catch(Exception e)
		{
     	
     	System.out.println("Exception in Object Creation " + e.toString());
		}
		
	}


	
}

